
Other modules
=============


MaxPoolChannels
~~~~~~~~~~~~~~~

.. autoclass:: e2cnn.nn.MaxPoolChannels
   :members:
   :show-inheritance:

